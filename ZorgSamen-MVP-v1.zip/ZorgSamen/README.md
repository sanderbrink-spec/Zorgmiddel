# ZorgSamen
Prototype voor een professionele zorgapp.

## Beveiligingsrichting
Ontworpen met NEN 7510:2024 als uitgangspunt. Certificering kan niet door de app zelf worden gegarandeerd; hiervoor zijn onder meer een ISMS, risicoanalyse, passende organisatorische maatregelen en een externe audit nodig.

## MVP
- Taken
- Overdracht
- Teamoverzicht
- Rollen/rechten als architectuurprincipe
- Auditlogging als architectuurprincipe
- Multi-tenant ontwerp als architectuurprincipe
- Geen echte cliëntgegevens in deze demo
