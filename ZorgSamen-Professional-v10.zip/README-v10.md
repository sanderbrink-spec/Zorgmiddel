# ZorgSamen Professional v10 / 2.0.0

## Updates in this version
- Prevents horizontal overflow in client details and other narrow mobile screens.
- Personal details are presented as stacked label/value pairs on small screens so long values remain readable.
- Adds clearer ZorgSamen branding to the sidebar, top area and demo banner.
- Adds a local demo administrator console with:
  - client list, edit, open and delete actions;
  - demo user creation, role assignment, permission checkboxes and deactivation;
  - a local audit list with JSON export.
- Keeps all data local to this prototype and clearly labels demo-only security.

## Build
Extract the ZIP and upload the contents into the root of the GitHub repository. Run the Android APK workflow in GitHub Actions and download the generated artifact.

## Security and production readiness
The administrator console is a UI prototype only. Roles, permissions and audit entries are stored in local WebView storage and can be changed by a device user. There is no server-side identity provider, enforced authorization API, encryption/key management, immutable audit trail, multi-factor authentication, or independent penetration test. Do not enter real client data or use this version to sign off real medication. A production launch requires a secure backend, authenticated user accounts, server-enforced least-privilege access, encryption in transit and at rest, backup/restore, monitoring, threat modelling, privacy review and independent security testing.
