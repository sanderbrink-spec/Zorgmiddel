package nl.zorgsamen.app;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.Uri;
import android.content.Intent;
import android.content.ActivityNotFoundException;

public class MainActivity extends Activity {
  private ValueCallback<Uri[]> uploadCallback;
  private static final int FILE_REQUEST = 1001;

  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    WebView w = new WebView(this);
    WebSettings s = w.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    s.setAllowContentAccess(true);
    s.setBuiltInZoomControls(false);
    w.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
        if (url != null && url.startsWith("mailto:")) {
          try { startActivity(new Intent(Intent.ACTION_SENDTO, Uri.parse(url))); }
          catch (ActivityNotFoundException e) { }
          return true;
        }
        return false;
      }
    });
    w.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, FileChooserParams params) {
        if (uploadCallback != null) uploadCallback.onReceiveValue(null);
        uploadCallback = callback;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(i, FILE_REQUEST);
        return true;
      }
    });
    w.loadUrl("file:///android_asset/index.html");
    setContentView(w);
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    if (requestCode == FILE_REQUEST && uploadCallback != null) {
      Uri[] result = null;
      if (resultCode == RESULT_OK && data != null) {
        if (data.getClipData() != null) {
          int n = data.getClipData().getItemCount();
          result = new Uri[n];
          for (int i = 0; i < n; i++) result[i] = data.getClipData().getItemAt(i).getUri();
        } else if (data.getData() != null) {
          result = new Uri[]{data.getData()};
        }
      }
      uploadCallback.onReceiveValue(result);
      uploadCallback = null;
    }
    super.onActivityResult(requestCode, resultCode, data);
  }
}
