# ZorgSamen Professional v5

Volledig interactieve demo-app voor het testen van de gebruikerservaring.

## Werkt in deze versie
- Dashboard met live aantallen uit lokale demo-data
- Cliënten zoeken, filteren, toevoegen en bewerken
- Cliëntdossier met Overzicht, Zorgplan, Rapportages, Medicatie en Documenten
- Zorgdoelen toevoegen, bewerken en voortgang aanpassen
- Rapportages toevoegen, bewerken en verwijderen
- Agenda-items toevoegen en afronden/openen
- Overdracht toevoegen en bekijken
- Berichten lezen en nieuwe berichten maken
- Statistieken
- Medicatie toevoegen, bewerken, verwijderen, aftekenen en als niet gegeven registreren met reden
- Medicatie importeren via CSV of JSON
- Demo-data exporteren en importeren als JSON
- Demo-data resetten
- Android bestandskiezer voor uploads
- Lokale opslag via WebView localStorage

## Medicatie CSV
Gebruik bijvoorbeeld:

cliënt,medicatie,dosis,route,tijd,frequentie
Jan de Vries,Metformine,500 mg,oraal,08:00,2x per dag
Petra van Dijk,Amlodipine,5 mg,oraal,09:00,1x per dag

## Belangrijk
Dit is een functionele UX-demo. Er wordt geen echte zorgdata verwerkt en er is geen productiebackend. Voor productie moeten onder meer identity management, autorisatie, audit logging, encryptie, back-ups, privacy- en bewaarbeleid, DPIA, koppelingen, testbeleid en onafhankelijke beveiligingsbeoordeling worden toegevoegd.


## v6 updates
- Mobile bottom navigation and dark navy/mint visual refinement.
- Speech-to-text button in report creation using Web Speech API where supported; always review transcript before saving.
- Work email address setting and mail-app compose shortcut. This is not OAuth mailbox sync and must not be used to email client-sensitive data.
- Demo banner added. No certification claim: this is still a local prototype with fictitious records.
