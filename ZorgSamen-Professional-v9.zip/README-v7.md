# ZorgSamen Professional v7

- Intro-/welkomstscherm met geanimeerd logo en zakelijke slogan.
- NL/EN taalkeuze en handleiding in eenvoudig Nederlands en Engels.
- Dashboard, cliënten, zorgplannen, doelen, agenda, rapportages, medicatie, overdracht, berichten, statistieken en instellingen.
- Spraak-naar-tekst waar browser/apparaat dit ondersteunt.
- Medicatie aftekenen, reden bij niet gegeven, CSV/JSON-import en demo-data import/export.
- Werkmailadres opslaan en e-mailapp openen.
- Android WebView-bestandskiezer en GitHub Actions debug-APK workflow.

## GitHub-build
Upload de uitgepakte inhoud van deze ZIP naar de repository-root. `app/`, `build.gradle`, `settings.gradle` en `.github/` moeten direct in de root staan. Open Actions en kies `ZorgSamen Android APK`; download de APK bij Artifacts.

## Veiligheidsgrenzen
Dit is een prototype met fictieve gegevens. Lokale browseropslag is niet geschikt als enige opslag voor echte zorggegevens. De app is niet gecertificeerd of onafhankelijk getest en niet geschikt voor echte medicatie-toediening of cliëntdossiers. Voor productie zijn onder meer een goedgekeurde backend, MFA, rolgebaseerde toegang, organisatie-isolatie, audittrail, back-up/herstel, DPIA, verwerkersafspraken, penetratietest en formele toetsing nodig. Controleer spraakherkenning en geïmporteerde gegevens altijd handmatig.
