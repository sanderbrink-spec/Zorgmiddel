# ZorgSamen Professional v8

- Mobile layout repaired: one bottom navigation bar, no duplicate sidebar, safe-area padding for Android system navigation, scrollable full-height content and modal dialogs.
- Reports: add, search, edit and delete, with automatic refresh after saving.
- Existing demo functions remain included: clients, care plans, agenda, medication sign-off, handover, messages, voice report support, import/export and guide.
- All data is fictional. This prototype is not certified for actual care records or medication administration.
- For GitHub build, upload extracted contents to repository root so `app/`, `build.gradle`, `settings.gradle` and `.github/` are directly in the root; start workflow `ZorgSamen Android APK`.
