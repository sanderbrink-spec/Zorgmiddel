# ZorgSamen Professional v9

## Wijzigingen
- Agenda: Dag, Week en Maand zijn nu zichtbare, werkende weergaveselecties; maandweergave toont een kalendergrid.
- Cliëntpersonalia: foto uploaden en lokaal bewaren, cliëntnummer, indicatieomschrijving, geldigheid, zorgteam en uren-tegoed toegevoegd.
- Detailweergave en tabbladen schalen op smalle schermen; cliënttabbladen kunnen horizontaal scrollen.
- Android-terugknop: navigeert eerst terug binnen de app. Op het dashboard vraagt twee keer kort na elkaar drukken om bevestiging, met Ja en Terug.
- Eigen ZorgSamen-launcher-pictogram in meerdere Android-resoluties.
- Bestaande rapportage- en mobiele layoutverbeteringen behouden.

## Build
Pak de ZIP uit en upload de inhoud naar de root van de GitHub-repository. Start vervolgens de Android APK workflow via GitHub Actions.

## Belangrijk
Dit is een prototype met fictieve gegevens. Geen echte cliëntgegevens of medicatie-registraties invoeren. De app is niet gecertificeerd voor productiegebruik. Een build en een volledige test op een echt Android-toestel blijven noodzakelijk.

- App version: 1.9.0 (versionCode 9).
- Android status- and navigation bars use a dark background to avoid the demo banner colliding visually with the status bar.
