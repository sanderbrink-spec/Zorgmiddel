package nl.zorgsamen.app;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.SystemClock;
import android.graphics.Color;
import android.view.Window;
import android.widget.Toast;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.Uri;
import android.content.Intent;
import android.content.ActivityNotFoundException;

public class MainActivity extends Activity {
  private ValueCallback<Uri[]> uploadCallback;
  private static final int FILE_REQUEST = 1001;
  private WebView webView;
  private long lastBackAt = 0;
  private boolean waitingBackResult = false;

  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    getWindow().setStatusBarColor(Color.rgb(6, 11, 19));
    getWindow().setNavigationBarColor(Color.rgb(6, 11, 19));
    if (android.os.Build.VERSION.SDK_INT >= 30) {
      getWindow().setDecorFitsSystemWindows(true);
    }
    webView = new WebView(this);
    WebSettings s = webView.getSettings();
    s.setJavaScriptEnabled(true);
    s.setDomStorageEnabled(true);
    s.setAllowFileAccess(true);
    s.setAllowContentAccess(true);
    s.setBuiltInZoomControls(false);
    webView.addJavascriptInterface(new Object() {
      @JavascriptInterface public void showExitPrompt() {
        runOnUiThread(() -> new AlertDialog.Builder(MainActivity.this)
          .setTitle("ZorgSamen afsluiten?")
          .setMessage("Weet u zeker dat u de app wilt afsluiten?")
          .setPositiveButton("Ja, afsluiten", (d, w) -> finish())
          .setNegativeButton("Terug", (d, w) -> { lastBackAt = 0; })
          .setCancelable(true)
          .show());
      }
    }, "AndroidApp");
    webView.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
        if (url != null && url.startsWith("mailto:")) {
          try { startActivity(new Intent(Intent.ACTION_SENDTO, Uri.parse(url))); }
          catch (ActivityNotFoundException e) { Toast.makeText(MainActivity.this, "Geen mailapp gevonden", Toast.LENGTH_SHORT).show(); }
          return true;
        }
        return false;
      }
    });
    webView.setWebChromeClient(new WebChromeClient() {
      @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
        if (uploadCallback != null) uploadCallback.onReceiveValue(null);
        uploadCallback = callback;
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        try { startActivityForResult(i, FILE_REQUEST); }
        catch (ActivityNotFoundException e) { uploadCallback.onReceiveValue(null); uploadCallback = null; }
        return true;
      }
    });
    setContentView(webView);
    webView.loadUrl("file:///android_asset/index.html");
  }

  @Override public void onBackPressed() {
    if (webView == null) { super.onBackPressed(); return; }
    if (waitingBackResult) return;
    waitingBackResult = true;
    webView.evaluateJavascript("(function(){return window.handleAndroidBack?window.handleAndroidBack():'exit'})()", value -> {
      waitingBackResult = false;
      if (isFinishing()) return;
      if (value != null && value.contains("handled")) {
        lastBackAt = 0;
        return;
      }
      long now = SystemClock.elapsedRealtime();
      if (now - lastBackAt <= 2000) {
        lastBackAt = 0;
        webView.evaluateJavascript("if(window.AndroidApp){window.AndroidApp.showExitPrompt()}", null);
      } else {
        lastBackAt = now;
        Toast.makeText(MainActivity.this, "Druk nogmaals op Terug om afsluiten te bevestigen", Toast.LENGTH_SHORT).show();
      }
    });
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    if (requestCode == FILE_REQUEST && uploadCallback != null) {
      Uri[] result = null;
      if (resultCode == RESULT_OK && data != null) {
        if (data.getClipData() != null) {
          int n = data.getClipData().getItemCount();
          result = new Uri[n];
          for (int i = 0; i < n; i++) result[i] = data.getClipData().getItemAt(i).getUri();
        } else if (data.getData() != null) result = new Uri[]{data.getData()};
      }
      uploadCallback.onReceiveValue(result);
      uploadCallback = null;
    }
    super.onActivityResult(requestCode, resultCode, data);
  }
}
