# ZorgSamen build

Android project voor de eerste ZorgSamen MVP.

## Build

Open deze map in Android Studio en kies **Build > Build APK(s)**.

De gegenereerde debug-APK staat normaal in:
`app/build/outputs/apk/debug/app-debug.apk`

Deze versie bevat bewust geen echte cliëntgegevens, backend of productie-authenticatie. Productiegebruik vereist verdere beveiligingsmaatregelen, privacydocumentatie, testen en een onafhankelijke beoordeling.
